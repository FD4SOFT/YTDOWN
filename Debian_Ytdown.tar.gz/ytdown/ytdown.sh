#FD4SOFT - https://sourceforge.net/p/ytdown
zenity --version
if [ $? -ge "1" ]; then
    echo
    echo "|-_-| OOOPS! É necessário que instale a extenssão 'zenity'."
    echo ">> Tentanto instalar o 'zenity' automáticamente..."
    echo "Obs: Você também pode instalar manualmente, caso tenha problemas."
    echo
    sudo apt install zenity
    if [ $? -eq "0" ]; then
        clear
        ytdown.sh
        else
            echo
            echo "#####################################################"
            echo "|-_-| OOOPS! Tivemos uma falha ao tentar instalar o 'zenity',"
            echo "tente instalar o zenity manualmente."
            echo "#####################################################"
            echo
            read -p "> Falha! Deseja sair?:" rp
            if [ $rp = "y" || $rp = "yes" || $rp = "s" || $rp = "sim" ]; then
                exit
                else
                    clear
                    ytdown.sh
            fi
    fi
fi
ffmpeg -version
if [ $? -ge "1" ]; then
    zenity --info --text="Oops! É necessário que instale a extenssão 'ffmpeg'." --title="YTDOWN"
    clear
    echo
    echo ">> Tentanto instalar o 'ffmpeg' automáticamente..."
    echo "Obs: Você também pode instalar manualmente, caso tenha problemas."
    echo
    sudo add-apt-repository ppa:jonathonf/ffmpeg-3
    sudo apt-get update; sudo apt-get install ffmpeg
    if [ $? -eq "0" ]; then
        clear
        ytdown.sh
        else
            echo
            echo "#####################################################"
            echo "|-_-| OOOPS!Tivemos uma falha ao tentar instalar o 'ffmpeg',"
            echo "mas você pode tentar instalar manualmente:"
            echo "Opção 1: https://ffmpeg.org/download.html"
            echo "Opção 2: https://launchpad.net/~jonathonf/+archive/ubuntu/ffmpeg-3"
            echo "Opção 3: https://launchpad.net/~jonathonf/+archive/ubuntu/tesseract"
            echo "#####################################################"
            echo
            read -p "> Falha! deseja sair?:" rp
            if [ $rp = "y" || $rp = "yes" || $rp = "s" || $rp = "sim" ]; then
                exit
                else
                    clear
                    ytdown.sh
            fi
    fi
fi
dire=~/Desktop
file=~/Desktop/YTDOWN.desktop
dire1=~/Área\ de\ trabalho
file1=~/Área\ de\ trabalho/YTDOWN.desktop
if [ -d "$dire" ]; then
    if [ -e "$file" ]; then
    echo "[OK]"
    else
    cp //usr/local/bin/ytdown/YTDOWN.desktop ~/Desktop
    fi
fi
if [ -d "$dire1" ]; then
    if [ -e "$file1" ]; then
    echo "[OK]"
    else
    cp //usr/local/bin/ytdown/YTDOWN.desktop ~/Área\ de\ trabalho
    fi
fi
selection=$(zenity --list "VÍDEO" "MÚSICA" "PLAYLIST VÍDEOS" "PLAYLIST MÚSICAS" "ATUALIZAR" --column="" --text="Modo Download" --width=500 --height=230 --title="YTDOWN")
case "$selection" in
"VÍDEO")
link=$(zenity --entry --text="Insira o link" --width=300 --height=100 --title="YTDOWN")
if [ $? -eq "1" ]; then
    ytdown.sh
fi
echo -------------------------------------------------------------
echo Download de $link para video/MP4:
echo -------------------------------------------------------------
if [ ! -d ~/yt-video ]; then
    mkdir ~/yt-video
else
    echo "[OK]"
fi
cd ~/yt-video
vnum=$(ls | grep -e ".mp4" | wc -l) #numero de videos na pasta
youtube-dl -f 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best' $link -o "~/yt-video/%(title)s.%(ext)s" | zenity --progress --text="Download para video/MP4\n" --width=300 --height=100 --pulsate --title="YTDOWN"
newvnum=$(ls | grep -e ".mp4" | wc -l)
if [ $vnum = $newvnum ]; then
    clear
    zenity --question --text="<big>Falha download!</big> \n Deseja tentar atualizar o YTDOWN?" --width=300 --height=150 --title="YTDOWN"
    if [ $? -eq "1" ]; then
        ytdown.sh
    else
        echo "Atualizando o engine do YTDOWN..."
        echo
        youtube-dl -U
        if [ $? -ge "1" ]; then
        zenity --info --text="<big>Falha na atualização!</big>\n Verifique sua conexão..." --width=300 --height=100 --icon-name=error --title="YTDOWN"
        ytdown.sh
        else
        zenity --info --text="Atualização realizada com êxito\n" --width=300 --height=100 --title="YTDOWN" --title="YTDOWN"
        ytdown.sh 
        fi
        fi
else
    echo
    echo "###########################################################"
    echo "###### O seu vídeo se encontra no diretório yt-video ######"
    echo "###########################################################"
    zenity --notification --text="Download com êxito! Video no diretório yt-video. \n Link: $link"
    ytdown.sh
fi
;;
"MÚSICA")
link=$(zenity --entry --text="Insira o link" --width=300 --height=100 --title="YTDOWN")
if [ $? -eq "1" ]; then
    ytdown.sh
fi
echo -------------------------------------------------------------
echo Download de $link para audio/FLAC:
echo -------------------------------------------------------------
if [ ! -d ~/yt-music ]; then
    mkdir ~/yt-music
else
    echo "[OK]"
fi
cd ~/yt-music
mnum=$(ls | grep -e ".flac" | wc -l)
youtube-dl -x --audio-format flac --audio-quality 0 $link -o "~/yt-music/%(title)s.%(ext)s" | zenity --progress --text="Download para audio/FLAC\n" --width=300 --height=100 --pulsate --title="YTDOWN"
newmnum=$(ls | grep -e ".flac" | wc -l)
if [ $mnum = $newmnum ]; then
    clear
    zenity --question --text="Falha download!\n Deseja tentar atualizar o YTDOWN?" --width=300 --height=100 --title="YTDOWN"
    if [ $? -eq "1" ]; then
        ytdown.sh
    else
        echo "Atualizando o engine do YTDOWN..."
        echo
        youtube-dl -U
        if [ $? -ge "1" ]; then
        zenity --info --text="<big>Falha na atualização!</big>\n Verifique sua conexão..." --width=300 --height=100 --icon-name=error --title="YTDOWN"
        ytdown.sh
        else
        zenity --info --text="Atualização realizada com êxito\n" --width=300 --height=100 --title="YTDOWN" --title="YTDOWN"
        ytdown.sh 
        fi
        fi
else
    echo
    echo "############################################################"
    echo "###### O seu música se encontra no diretório yt-music ######"
    echo "############################################################"
    zenity --notification --text="Download com êxito! Música no diretório yt-music. \n Link: $link"
    ytdown.sh
fi
;;
"PLAYLIST VÍDEOS")
link=$(zenity --entry --text="Insira o link" --width=300 --height=100 --title="YTDOWN")
if [ $? -eq "1" ]; then
    ytdown.sh
fi
echo -------------------------------------------------------------
echo Download da playlist para video/MP4:
echo -------------------------------------------------------------
if [ ! -d ~/yt-video/Playlists ]; then
    mkdir -p ~/yt-video/Playlists
else
    echo "[OK]"
fi
cd ~/yt-video/Playlists
lvnum=$(ls -Rl Playlists | egrep -c "^d") #Conta recursivamente todas as subpastas em Playlists Obs: Conta recursivamente todos arquivos -> ls -Rl $pasta | egrep -c "^\-"
youtube-dl -f 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best' -o '~/yt-video/Playlists/%(playlist)s/%(playlist_index)s - %(title)s.%(ext)s' $link | zenity --progress --text="Download playlist para video/MP4\n" --width=300 --height=100 --pulsate --title="YTDOWN"
newlvnum=$(ls -Rl Playlists | egrep -c "^d")
if [ $lvnum = $newlvnum ]; then
    clear
    zenity --question --text="Falha download!\n Deseja tentar atualizar o YTDOWN?" --width=300 --height=100 --title="YTDOWN"
    if [ $? -eq "1" ]; then
        ytdown.sh
    else
        echo "Atualizando o engine do YTDOWN..."
        echo
        youtube-dl -U
        if [ $? -ge "1" ]; then
        zenity --info --text="<big>Falha na atualização!</big>\n Verifique sua conexão..." --width=300 --height=100 --icon-name=error --title="YTDOWN"
        ytdown.sh
        else
        zenity --info --text="Atualização realizada com êxito\n" --width=300 --height=100 --title="YTDOWN" --title="YTDOWN"
        ytdown.sh 
        fi
        fi
else
    echo
    echo "#################################################"
    echo "###### Playlist está em yt-video/Playlists ######"
    echo "#################################################"
    zenity --notification --text="Download com êxito! Playlist no diretório yt-video/Playlists. \n Link: $link"
fi
;;
"PLAYLIST MÚSICAS")
link=$(zenity --entry --text="Insira o link" --width=300 --height=100 --title="YTDOWN")
if [ $? -eq "1" ]; then
    ytdown.sh
fi
echo -------------------------------------------------------------
echo Download da playlist para audio/FLAC:
echo -------------------------------------------------------------
if [ ! -d ~/yt-music/Playlists ]; then
    mkdir -p ~/yt-music/Playlists
else
    echo "[OK]"
fi
cd ~/yt-music/Playlists
lmnum=$(ls -Rl Playlists | egrep -c "^d")
youtube-dl -x --audio-format flac --audio-quality 0 -o '~/yt-music/Playlists/%(playlist)s/%(playlist_index)s - %(title)s.%(ext)s' $link | zenity --progress --text="Download para audio/FLAC\n" --width=300 --height=100 --pulsate --title="YTDOWN"
newlmnum=$(ls -Rl Playlists | egrep -c "^d")
if [ $lmnum = $newlmnum ]; then
    clear
    zenity --question --text="Falha download!\n Deseja tentar atualizar o YTDOWN?" --width=300 --height=100 --title="YTDOWN"
    if [ $? -eq "1" ]; then
        ytdown.sh
    else
        echo "Atualizando o engine do YTDOWN..."
        echo
        youtube-dl -U
        if [ $? -ge "1" ]; then
        zenity --info --text="<big>Falha na atualização!</big>\n Verifique sua conexão..." --width=300 --height=100 --icon-name=error --title="YTDOWN"
        ytdown.sh
        else
        zenity --info --text="Atualização realizada com êxito\n" --width=300 --height=100 --title="YTDOWN" --title="YTDOWN"
        ytdown.sh 
        fi
        fi
else
    echo
    echo "#################################################"
    echo "###### Playlist está em yt-music/Playlists ######"
    echo "#################################################"
    zenity --notification --text="Download com êxito! Playlist no diretório yt-music/Playlists. \n Link: $link"
fi
;;
"ATUALIZAR")
        echo "Atualizando o engine do YTDOWN..."
        echo
        youtube-dl -U
        if [ $? -ge "1" ]; then
        zenity --info --text="<big>Falha na atualização!</big>\n Verifique sua conexão..." --width=300 --height=100 --icon-name=error --title="YTDOWN"
        ytdown.sh
        else
        zenity --info --text="Atualização realizada com êxito\n" --width=300 --height=100 --title="YTDOWN" --title="YTDOWN"
        ytdown.sh 
        fi
;;
*)
clear
echo "##################################"
echo "###### Operação cancelada! #######"
echo "##################################"
echo
echo "Encontrou um bug?"
echo "Por favor reporte isso na aba do projeto: https://sourceforge.net/p/ytdown/discussion/"
zenity --question --text="Deseja executar novamente o YTDOWN?" --width=300 --height=100 --title="YTDOWN"
if [ $? -eq "1" ]; then
    exit
else
    ytdown.sh
fi
;;
esac
